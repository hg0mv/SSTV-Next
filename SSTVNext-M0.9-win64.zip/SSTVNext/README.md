# SSTV Next M0.9

Önálló SSTV adó-vevő program X11 felülettel. A rádióvezérlés (rigctld), a
hangkártyakezelés és az ADIF-log a DigiPan Nextből átvett, bevált kód.

## Fordítás

Kell hozzá: `libx11-dev`, `libasound2-dev` (Debian/Ubuntu csomagnevek), gcc, make.
A PNG/JPEG és a TrueType betűk kezeléséhez szükséges stb könyvtárak a `third_party/` mappában vannak
(public domain). A betűtípusokat a rendszer `/usr/share/fonts` mappájából veszi (pl. DejaVu, Ubuntu, Liberation).

A felület saját szoftveres rajzolóval készül (`ui.c`): élsimított TrueType betűk, lekerekített
panelek, színátmenetek, árnyékok. A felület betűtípusa Ubuntun az Ubuntu család, ha nincs, DejaVu
Sans; más betűtípus az `SSTV_UI_FONT=/út/a/betuhoz.ttf` környezeti változóval adható meg.

    make

Ez öt programot készít:

| program     | mire való |
|-------------|-----------|
| `sstv_next` | az X11 adó-vevő |
| `sstv_dec`  | parancssori dekóder: WAV felvételből képek |
| `sstv_enc`  | parancssori kódoló: képből WAV (teszteléshez, szimulált hibákkal) |
| `drm_dec`   | digitális (HamDRM) dekóder: WAV felvételből a vett fájlok |
| `drm_enc`   | digitális (HamDRM) kódoló: fájlból WAV |

A JPEG 2000 képek (a QSSTV ezt küldi alapból) megjelenítéséhez a rendszer `libopenjp2` könyvtárát
használja futás közben (Ubuntun a `libopenjp2-7` csomag, szinte mindig fent van). Ha nincs meg,
a vett fájl akkor is elmentődik, csak nem jelenik meg.

### Windows változat

A Windows programot Linuxon, keresztfordítással készítem (MinGW-w64 / llvm-mingw):

    make win CC=... WINCC=x86_64-w64-mingw32-gcc WINRES=x86_64-w64-mingw32-windres

Az eredmény a `win/dist/SSTVNext` mappába kerül. A Windows-specifikus részek a `win/`
mappában vannak (`winx.c`: az Xlib kis részhalmaza Win32 fölött, `glob.c`, pótló fejlécek);
a hang (`audio.c`: WinMM) és a rádióvezérlés (`rig.c`: Winsock, a mellékelt `rigctld.exe`
indítása) `#ifdef _WIN32` ágakban. A csomagba kerülő külső fájlok (Hamlib Windows kiadás,
OpenJPEG `openjp2.dll`) a `win/bundle` mappából másolódnak, ezeket a hivatalos GitHub
kiadásokból kell letölteni (a forráscsomag nem tartalmazza őket). A felhasználói leírás:
`win/OLVASSEL.txt`.

## Használat

    ./sstv_next

- **Audio input**: válaszd ki a rádióhoz kötött hangkártyát (`plughw:N,0` vagy `default`).
  A program 11025 Hz-en dolgozik, a plughw ezt bármelyik kártyán megoldja.
- **Radio**: ugyanaz a párbeszédablak, mint a DigiPanban. Első indításkor a hívójelet és a
  rádióbeállítást átveszi a DigiPan beállításaiból. A saját rigctld a 14533-as porton fut,
  így a DigiPannal egyszerre is mehet.
- **Vétel**: automatikus. A módot a VIS-kódból ismeri fel; ha a VIS lemaradt (gyenge jel,
  QSB, kép közepén kapcsoltál be), akkor a szinkronimpulzusok ütemezéséből, kb. 10 sor után.
  Ilyenkor az elhangolást is a szinkronjelekből méri. Soronként rajzolja a képet, menet közben
  javítja a ferdeséget, a végén elmenti PNG-be (`~/sstv/rx`). Ha a jel 8 másodpercig elveszik,
  vagy vétel közben új VIS érkezik (másik állomás kezd), a részképet `_part` jelöléssel menti.
  - **RX mode**: alapból „Auto (all modes)”. Rögzíthetsz egy módot is (kattintás: következő,
    jobb gomb / görgő: előző).
  - **Save now**: a folyamatban lévő képet azonnal lezárja és elmenti.
  - **QRM filt**: a ráadott beszéd (SSB QRM) okozta színes szemcséket a szomszédos sorokból
    pótolja; a vékony vonalakat és a feliratokat békén hagyja. Alapból be van kapcsolva.
  - **Zavar a fejlécen**: ha a beszéd részben elnyomja a VIS-t, a fejléc kerete alapján a
    program tudja, hol kezdődik a kép, a módot pedig az első ~6 másodperc szinkronjeleiből
    dönti el (állapotsor: „VIS damaged by QRM ...”), így a kép az elejétől meglesz. Egy ép
    VIS-t is ellenőriz a szinkronjelekkel, és ha két bit átbillent, átvált a helyes módra.
  - **Tuning**: a VIS-fejléc 1900 Hz-es vezető hangját hangold a sárga vonalra.
  - A jobb alsó galériában a képre kattintva nagyban megnézheted, a **Live** gomb visz vissza.
- **Adás**: a `~/sstv/tx` mappa képei közül választhatsz háttérnek (`<` `>` vagy a nyilak), PNG/JPEG/BMP/PPM.
  A kép a mód méretére vágódik (középről). A **Mode** gomb: kattintás a következő, jobb gomb / görgő az előző mód.
  A **Templ** sorban választod ki, melyik sablon kerüljön a képre. **Send / F1** indítja, **Esc** megszakítja.
  A PTT kezelése és a biztonsági leállítások ugyanazok, mint a DigiPanban.
- **Sablonszerkesztő** (Templ → **Edit**), az MMSSTV sablonjaihoz hasonlóan:
  - Objektumok: **szöveg** (TrueType betűk, körvonal, árnyék), **téglalap**, **ellipszis**, **vonal**,
    **kép**. A galériában egy vett képre kattintva beilleszti (válaszképhez), a *Picture* gomb a legutóbbit.
  - Egér: kattintás = kijelölés, húzás = mozgatás, a kék sarokpont húzása = átméretezés (szövegnél a
    betűméret), vonalnál a két végpont. Billentyű: Del törlés, nyilak 1 pixeles léptetés, Esc kilépés.
  - Eszköztár: szöveg, betűtípus (`<` `>`), körvonal/árnyék/kitöltés, kitöltő- és vonalszín (Fill/Line),
    méret, vonalvastagság, átlátszóság, rétegsorrend (Up/Down), másolás, törlés.
  - Makrók a szövegben, adáskor töltődnek ki: `%M` saját hívójel, `%C` a másik állomás (a log sor Call
    mezőjéből), `%R` RST (S mező), `%T` UTC idő, `%D` dátum, `%F` frekvencia.
  - Sablonok: név + **Save** (új névvel mentve másolat lesz), **New**, **Delete tpl**, `<` `>` váltás.
    A **Done** menti és visszalép. Első induláskor három sablon jön létre: *Call* (a régi felirat),
    *CQ* és *QSO reply*. Helyük: `~/.config/sstvnext/templates/*.tpl` (szövegfájl).
  - Szerkesztés közben a vétel a háttérben fut, az állapota a kép alatt látszik.
- **FSK ID (hívójel a kép után)**, az MMSSTV / QSSTV szabványa szerint:
  - Vételnél a program figyeli a kép utáni FSK ID-t (2100/1900 Hz, 45,45 baud), és ha jön,
    kiírja ("FSK ID: HA5XYZ"). Digitális vételnél az adó hívójele a jelben van, azt is
    felismeri. Ha a log **Call** mezője üres (és épp nem írsz bele), a program beírja a
    hívójelet, és elindítja a QSO idejét. Egy már beírt hívójelet nem ír felül.
  - Adásnál az analóg módokban a Mode sor alatti **FSK ID on/off** gombbal kapcsolható
    (alapból bekapcsolva): a kép után kb. 2 másodpercben elküldi a saját hívójeledet.
  - Kb. 8 dB jel/zaj viszonyig és ±100 Hz elhangolásig működik.
- **Log**: Call, RST (alapból 595), MHz (a rádióból jön) → **Log QSO**. Alapból ugyanabba a
  `~/digipan_log.adi` fájlba ír, mint a DigiPan, MODE=SSTV, a konkrét mód a COMMENT mezőben.

## Digitális SSTV (HamDRM)

Az EasyPal / QSSTV / WinDRM által használt digitális mód, saját megvalósításban (a DRM szabvány
alapján, a QSSTV-vel bitre azonos jelalakkal).

- **Vétel**: automatikus, az analóg vétellel párhuzamosan fut, nem kell átkapcsolni. Ha digitális
  jelet talál, a kép bal felső sarkában `DIGITAL` jelzés, a mód (A/B/E, QAM, védelem, sávszélesség)
  és az adó hívójele látszik; alul a kapott szegmensek száma, a jel/zaj viszony és az elhangolás.
  A kép a vétel közben fokozatosan rajzolódik ki (JPEG). Elhangolás ±150 Hz-ig, hangkártya-
  órajel eltérés több száz ppm-ig nem gond, HF fadinget (többutas terjedés) is kezel.
  A vett fájl eredeti formában a `~/sstv/rx/digital` mappába kerül, a kép PNG-ként a galériába.
  Ha a jel elmegy és hiányzik néhány szegmens, a meglévő részt `_part` jelöléssel menti.
- **Adás**: a **Mode** gombon a 25 analóg mód után jön a **Digital DRM**. Ekkor két új sor jelenik meg:
  - `DRM`: robusztussági mód (**A** jó jelnél, **B** általános, **E** gyenge/fadinges jelnél),
    moduláció (**4/16/64-QAM**), védelem (**High**/**Norm**), sávszélesség (**2.3k**/**2.5k**).
    Kattintás: következő érték, jobb gomb / görgő: előző.
  - `Pic`: képméret (320x240 ... 800x600) és a JPEG felső mérethatára (6 ... 64 kB). A program a
    lehető legjobb JPEG minőséget választja, ami belefér. A Mode melletti címkén a várható adásidő
    és a tényleges fájlméret látszik.
  - A sablonok ugyanúgy rákerülnek a képre, mint analóg módban. Esc megszakítja az adást.
  - **RS** gomb (a `Pic` sor végén): Reed-Solomon védelem (**no RS**, **RS1** ... **RS4**). A képfájl
    hosszabb lesz (RS1 +14 %, RS2 +33 %, RS3 +60 %, RS4 +100 %), cserébe a vevő akkor is helyreállítja
    a teljes képet, ha a szegmensek egy része elveszett (RS4-nél akár a fele). A vevő fél a QSSTV és
    az EasyPal `.rs1`–`.rs4` fájljait is fogadja. Az adásidőt a címke ezzel együtt mutatja.
  - Tipp: a leggyakoribb beállítás **B / 16-QAM / Norm / 2.5k**; rossz terjedésnél **E / 4-QAM / High**.
- **Ismétléskérés (BSR)**, az EasyPal / QSSTV szokása szerint:
  - Ha egy vett digitális képből szegmensek hiányoznak, a kép alatti sorban megjelenik az
    **Ask repeat** gomb. Megnyomva a program elküldi a hiányzó szegmensek listáját (`bsr.bin`
    fájl) az aktuális DRM beállításokkal. Ha az adó állomás válaszol, a hiányzó részek beépülnek
    a már meglévő képbe.
  - Ha valaki a *te* képedhez kér ismétlést, az üzenetsorban megjelenik ("BSR from ...") és a
    **Rescan** gomb helyén egy **Fix N** gomb (N = kért szegmensek). Megnyomva csak a hiányzó
    részeket küldi el újra, az eredeti beállításokkal. A program az utolsó 6 elküldött képre
    emlékszik (a program újraindításáig).
  - Az ALC-t tartsd alacsonyan (OFDM jel): a hangerőt úgy állítsd, hogy az ALC épp ne mozduljon.

### Tesztelés rádió nélkül

    ./sstv_next -f felvetel.wav -s 10     # WAV felvétel a vevőbe, tízszeres sebességgel
    ./sstv_next -x adas.wav               # az adás WAV fájlba megy a hangkártya helyett
    ./sstv_dec adas.wav                   # visszafejtés ellenőrzésre (-r: QRM-szűrő nélkül)
    ./drm_enc -m B -q 16 -c HG0MV kep.jpg drm.wav     # digitális adás WAV-ba
    ./drm_dec -v -o /tmp drm.wav                       # digitális vétel WAV-ból
    ./drm_enc -r 2 kep.jpg drm.wav                     # Reed-Solomon védelemmel (kep.rs2)
    ./drm_dec -b bsr.txt drm.wav                       # ismétléskérés a hiányzó szegmensekre
    ./drm_enc -F bsr.txt kep.jpg fix.wav               # válasz egy ismétléskérésre

## Támogatott módok

| család | módok |
|--------|-------|
| Robot | Robot 36, Robot 72 |
| Scottie | S1, S2, S3, S4, DX |
| Martin | M1, M2, M3, M4 |
| PD | PD50, PD90, PD120, PD160, PD180, PD240, PD290 |
| Wraase | SC2-60, SC2-120, SC2-180 |
| Pasokon | P3, P5, P7 |
| egyéb | FAX480 (fekete-fehér) |

VIS nélkül az S3/S4 és M3/M4 nem különböztethető meg az S1/S2 és M1/M2 módtól
(azonos az időzítésük), ilyenkor a teljes magasságú változat jelenik meg.
Az MMSSTV saját módjai (MP, MR, ML, kiterjesztett 16 bites VIS) még nincsenek benne.

## Fájlok

| fájl | tartalom |
|------|----------|
| `modes.c` | módtáblázat (új mód = egy sor) |
| `demod.c` | FM-diszkriminátor (pillanatnyi frekvencia) |
| `rx.c` | VIS-keresés, szinkronkövetés, robusztus ferdeségillesztés, képépítés |
| `tx.c` | kódoló (fázisfolytonos FM, VIS-fejléc) |
| `tpl.c` | sablonok: objektumok, TrueType szöveg (stb_truetype), rajzolás, mentés |
| `live.c` | élő vételi motor (saját szálon), analóg + digitális |
| `drm_common.c` | HamDRM táblák, cellatérkép, konvolúciós kód, Viterbi, CRC |
| `drm_tx.c` / `drm_rx.c` | digitális adó (OFDM) / vevő (szinkron, csatornabecslés, dekódolás) |
| `mot.c` | képátvitel csomagokban (MOT objektum, szegmensek) |
| `jp2.c` | JPEG 2000 betöltés a rendszer OpenJPEG könyvtárával |
| `fskid.c` | FSK ID (hívójel a kép után): dekóder és kódoló |
| `rsfile.c` | Reed-Solomon védett fájlok (.rs1–.rs4): kódoló, hibajavító dekóder |
| `audio.c`, `rig.c`, `adif.c` | hangkártya, rigctld, ADIF-log (DigiPanból) |
| `config.c` | beállítások (`~/.config/sstvnext/config`) |
| `ui.c` | rajzoló réteg: képpuffer, élsimított alakzatok, TrueType szöveg, XPutImage |
| `sstv_next.c` | X11 felület |
